cd ../src/test_lib_json
timeout 1s ./jsoncpp_test --test ReaderTest/allowNumericKeysTest_1
