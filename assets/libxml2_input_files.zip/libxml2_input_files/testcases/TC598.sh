cd ../
export LD_LIBRARY_PATH="/home/yangheechan/mbfl-dataset-gen/LIGNex1_FL_dataset_LIBXML2/subjects/libxml2/.libs:$LD_LIBRARY_PATH"
./.libs/runtest -quiet --single-tc TC598
