cp anyName1_0.err ../../subjects/libxml2/result/relaxng/
cp anyName1.rng ../../subjects/libxml2/test/relaxng/
cp anyName1_0.xml ../../subjects/libxml2/test/relaxng/
